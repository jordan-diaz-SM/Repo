# Tienda Virtual

#### Rama V1, \[SOL\]ID

    - Rama v1.0 Tiene la clase Main que no cumple con el principio SRP
 

